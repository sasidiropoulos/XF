<?php

namespace XFRM\Repository;

use XF\Repository\AbstractPrefix;

class ResourcePrefix extends AbstractPrefix
{
	protected function getRegistryKey()
	{
		return 'xfrmPrefixes';
	}

	protected function getClassIdentifier()
	{
		return 'XFRM:ResourcePrefix';
	}

	public function getVisiblePrefixListData()
	{
		if (!method_exists($this, '_getVisiblePrefixListData'))
		{
			// in case this version of XFRM is used on an older version of XF.
			return $this->getPrefixListData();
		}

		$prefixMap = $this->finder('XFRM:CategoryPrefix')
			->with('Category', true)
			->with('Category.Permissions|' . \XF::visitor()->permission_combination_id)
			->fetch();

		$isVisibleClosure = function(\XFRM\Entity\ResourcePrefix $prefix) use ($prefixMap)
		{
			$isVisible = false;

			foreach ($prefixMap AS $categoryPrefix)
			{
				/** @var \XFRM\Entity\CategoryPrefix $categoryPrefix */
				if ($prefix->prefix_id == $categoryPrefix->prefix_id)
				{
					$isVisible = $categoryPrefix->Category->canView();
				}
			}

			return $isVisible;
		};
		return $this->_getVisiblePrefixListData($isVisibleClosure);
	}
}